module.exports = {
    PORT: "8003",
    
    color: "#dfdb10",
    hostname: "ReHost - NODE02",
    logo: "https://panel.rehost.hu/themes/enigma_premium/img/logo.png",
    apikey: "asd"
}