// By: Dominikhun250 

function formatMemorySize(sizeInBytes) {
      return `${(sizeInBytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
    }

    function formatUptime(seconds) {
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      return `${hours} hours, ${minutes} minutes`;
    }

    function updateBar(barElement, percentage, text) {
      if (barElement) {
        barElement.style.width = `${percentage}%`;
        barElement.textContent = text;

        barElement.classList.remove('bg-90', 'bg-50', 'bg-0');

        if (percentage >= 90) {
          barElement.classList.add('bg-90');
        } else if (percentage >= 50) {
          barElement.classList.add('bg-50');
        } else {
          barElement.classList.add('bg-0');
        }
      }
    }

    function fetchStats() {
      fetch('/stats')
        .then(response => response.json())
        .then(data => {
          document.getElementById('upTime').textContent = formatUptime(data.upTime);

          const cpuUsagePercentage = (data.cpuUsage / data.maxCpuUsage) * 100;
          const cpuUsageBar = document.getElementById('cpuUsage');
          if (cpuUsageBar) {
            updateBar(
              cpuUsageBar,
              (cpuUsagePercentage.toFixed(2) * data.numCpus).toFixed(2),
              `${(cpuUsagePercentage.toFixed(2) * data.numCpus).toFixed(2)}%`
            );
            document.getElementById('cpuUsageText').textContent = `${(data.cpuUsage.toFixed(2) * data.numCpus).toFixed(2)}% / ${data.maxCpuUsage}%`;
          }

          const usedMemPercentage = (data.usedMem / data.totalMem) * 100;
          const usedMemBar = document.getElementById('usedMem');
          if (usedMemBar) {
            updateBar(
              usedMemBar,
              usedMemPercentage.toFixed(2),
              `${usedMemPercentage.toFixed(2)}%`
            );
            document.getElementById('usedMemText').textContent = `${formatMemorySize(data.usedMem)} / ${formatMemorySize(data.totalMem)}`;
          }

          const usedDiskPercentage = (data.usedDisk / data.totalDisk) * 100;
          const usedDiskBar = document.getElementById('usedDisk');
          if (usedDiskBar) {
            updateBar(
              usedDiskBar,
              usedDiskPercentage.toFixed(2),
              `${usedDiskPercentage.toFixed(2)}%`
            );
            document.getElementById('usedDiskText').textContent = `${formatMemorySize(data.usedDisk)} / ${formatMemorySize(data.totalDisk)}`;
          }
        });
    }

    setInterval(fetchStats, 1000);
    fetchStats();