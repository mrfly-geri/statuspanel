// By: Dominikhun250

document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
});